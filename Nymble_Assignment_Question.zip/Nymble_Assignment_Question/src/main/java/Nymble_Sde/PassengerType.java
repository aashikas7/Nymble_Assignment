package Nymble_Sde;

public enum PassengerType {
    STANDARD,
    GOLD,
    PREMIUM
}
